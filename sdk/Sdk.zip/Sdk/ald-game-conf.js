exports.app_key = "778fe3a3df9f2fad46f85b885ed9ec7b"; //请在此行填写从阿拉丁后台获取的appkey
exports.getLocation = false; //默认不获取用户坐标位置